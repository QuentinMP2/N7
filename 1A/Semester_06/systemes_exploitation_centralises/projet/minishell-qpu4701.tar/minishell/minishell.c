#include <stdio.h>
#include <stdlib.h>
#include "readcmd.h"
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <fcntl.h>

#define MAX_TUBES 10

/* Variables globales nécessaires pour faire passer des informations entre
 * le père et le traitement du signal SIGCHLD.
 */
pid_t pid_fork;
bool forkForegroundFinished;

void traitementSIGCHLD() {
    int status;
    pid_t pid = waitpid(-1, &status, WNOHANG|WUNTRACED|WCONTINUED);
    if (pid == -1)
        printf("Erreur de terminaison du fils\n");

    if (WIFEXITED(status))
        printf("Terminaison du fils de pid %d avec un code de retour %d\n", pid, WEXITSTATUS(status));
    else if (WIFSTOPPED(status))
        printf("Suspension du fils de pid %d avec un code de retour %d\n", pid, WEXITSTATUS(status));
    else if (WIFCONTINUED(status))
        printf("Reprise du fils de pid %d avec un code de retour %d\n", pid, WEXITSTATUS(status));
    else if (WIFSIGNALED(status))
        printf("Envoi d'un signal vers le fils de pid %d avec un code de retour %d\n", pid, WEXITSTATUS(status));

    if (pid == pid_fork)
        forkForegroundFinished = true;
    else
        forkForegroundFinished = false;
}

int main(void) {
    struct sigaction action;

    // Sigaction pour SIGCHLD
    action.sa_handler = traitementSIGCHLD;
    sigemptyset(&action.sa_mask);
    action.sa_flags = SA_RESTART;
    sigaction(SIGCHLD, &action, NULL);

    // Masque des signaux SIGINT et SIGTSTP
    sigset_t mask_SIGINT_SIGTSTP;
    sigemptyset(&mask_SIGINT_SIGTSTP);
    sigaddset(&mask_SIGINT_SIGTSTP, SIGINT);
    sigaddset(&mask_SIGINT_SIGTSTP, SIGTSTP);
    sigprocmask(SIG_BLOCK, &mask_SIGINT_SIGTSTP, NULL);

    bool fini = false;

    while (!fini) {
        printf("> ");
        struct cmdline *commande = readcmd();

        if (commande == NULL) {
            // commande == NULL -> erreur readcmd()
            perror("erreur lecture commande \n");
            exit(EXIT_FAILURE);
    
        } else {

            if (commande->err) {
                // commande->err != NULL -> commande->seq == NULL
                printf("erreur saisie de la commande : %s\n", commande->err);
        
            } else {
                // Calcul du nombre de commandes
                int nbCommandes = 0;
                while(commande -> seq[nbCommandes]) {
                    nbCommandes++;
                }


                // Calcul du nombre de tubes
                int nbTubes = nbCommandes - 1;
                
                int tubes[MAX_TUBES][2];
                for (int i = 0; i < nbTubes; i++) {
                    if (pipe(tubes[i]) == -1) {
                        printf("Erreur création du tube %d\n", i);
                        exit(EXIT_FAILURE);
                    }
                }
                

                /* Pour le moment le programme ne fait qu'afficher les commandes 
                   tapees et les affiche à l'écran. 
                   Cette partie est à modifier pour considérer l'exécution de ces
                   commandes 
                */
                int indexseq = 0;
                char **cmd;
                while ((cmd = commande->seq[indexseq])) {

                    if (cmd[0]) {
                        if (strcmp(cmd[0], "exit") == 0) {
                            fini = true;
                            printf("Au revoir ...\n");
                        }
                        else {
                            printf("commande : ");
                            int indexcmd = 0;
                            while (cmd[indexcmd]) {
                                printf("%s ", cmd[indexcmd]);
                                indexcmd++;
                            }
                            printf("\n");

                            pid_fork = fork();
                            if (pid_fork == -1) {
                                // Erreur : le fork ne s'est pas créé
                                perror("Erreur création fork\n");
                                exit(EXIT_FAILURE);

                            } else if (pid_fork == 0) {
                                // Fils

                                if (nbCommandes != 1) {
                                    if (indexseq == 0) {
                                        if (dup2(tubes[0][1], 1) == -1) {
                                            perror("Erreur duplication descripteur de fichier\n");
                                            exit(EXIT_FAILURE);
                                        } 
                                        if (close(tubes[0][0]) == -1) {
                                            perror("Erreur fermeture lecture tube\n");
                                            exit(EXIT_FAILURE);
                                        } 
                                    } else if (indexseq == nbCommandes-1) {
                                        if (dup2(tubes[nbTubes-1][0], 0) == -1) {
                                            perror("Erreur duplication descripteur de fichier\n");
                                            exit(EXIT_FAILURE);
                                        }
                                        if (close(tubes[nbTubes-1][1]) == -1) {
                                            perror("Erreur fermeture écriture tube\n");
                                            exit(EXIT_FAILURE);
                                        } 
                                    } else {
                                        if (dup2(tubes[indexseq][1], 1) == -1) {
                                            perror("Erreur duplication descripteur de fichier\n");
                                            exit(EXIT_FAILURE);
                                        } 
                                        if (dup2(tubes[indexseq-1][0], 0) == -1) {
                                            perror("Erreur duplication desctipteur de fichier\n");
                                            exit(EXIT_FAILURE);
                                        } 
                                        if (close(tubes[indexseq][0]) == -1) {
                                            perror("Erreur fermeture lecture tube\n");
                                            exit(EXIT_FAILURE);
                                        } 
                                        if (close(tubes[indexseq-1][1]) == -1) {
                                            perror("Erreur fermeture écriture tube\n");
                                            exit(EXIT_FAILURE);
                                        } 
                                    }

                                    // Fermer les entrées/sorties des tubes non utilisés
                                    for (int i = 0; i < indexseq - 1; i++) {
                                        if (close(tubes[i][0]) == -1) {
                                            printf("Erreur fermeture lecture du tube %d\n", i);
                                        }

                                        if (close(tubes[i][1]) == -1) {
                                            printf("Erreur fermeture écriture du tube %d\n", i);
                                        } 
                                    }
                                }

                                // Gestion de la redirection entrante
                                if (commande -> in != NULL) {
                                    int src;
                                    if ((src = open(commande -> in, O_RDONLY)) == -1) {
                                        perror("Erreur ouverture in\n");
                                        exit(EXIT_FAILURE);
                                    }

                                    if (dup2(src, 0) == -1) {
                                        perror("Erreur duplication descripteur de fichier\n");
                                        exit(EXIT_FAILURE);
                                    } 
                                    
                                    if (close(src) == -1) {
                                        perror("Erreur fermeture desctipteur de fichier\n");
                                    } 
                                }

                                // Gestion de la redirection sortante
                                if (commande -> out != NULL) {
                                    int desc;
                                    if ((desc = open(commande -> out, O_WRONLY | O_CREAT | O_TRUNC, 0666)) == -1) {
                                        perror("Erreur ouverture out\n");
                                        exit(EXIT_FAILURE);
                                    }
                                    
                                    if (dup2(desc, 1) == -1) {
                                    	perror("Erreur duplication du descripteur de fichier\n");
                                    	exit(EXIT_FAILURE);
                                    }
                                    
                                    if (close(desc) == -1) {
                                    	perror("Erreur fermeture descripteur de fichier\n");
                                    	exit(EXIT_FAILURE);
                                    }
                                }

                                // Remise des masques par défaut
                                sigprocmask(SIG_UNBLOCK, &mask_SIGINT_SIGTSTP, NULL);


                                if (commande -> backgrounded != NULL) {
                                    // Définition d'un nouveau groupe pour les fils en arrière-plan
                                    if (setpgrp() == -1) {
                                        perror("Erreur set groupe\n");
                                    }
                                }

                                if (execvp(cmd[0], cmd) == -1) {
                                    perror("Erreur exécution commande\n");
                                    exit(EXIT_FAILURE);
                                }
                            } else {
                                // Père

                                if ((indexseq == nbCommandes - 1) && (commande->backgrounded == NULL)) {
                                    // Fermer les tubes
                                    for (int i = 0; i < nbTubes; i++) {
                                        if (close(tubes[i][0]) == -1) {
                                            printf("Erreur fermeture lecture du tube %d\n", i);
                                        }

                                        if (close(tubes[i][1]) == -1) {
                                            printf("Erreur fermeture écriture du tube %d\n", i);
                                        }
                                    }
                                    
                                    // Attendre la terminaison du fils
                                    while (!forkForegroundFinished) {
                                    	/* Cast en void pour bien faire comprendre que j'ai ignoré 
                                         * la valeur de retour de pause (bonne pratique de programmation)
                                         */ 
                                        (void)pause();
                                    }
                                    forkForegroundFinished = false;
                                }
                            }
                        }

                        indexseq++;
                    }
                }
            }
        }
    }
    return EXIT_SUCCESS;
}
